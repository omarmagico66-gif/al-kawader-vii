'use client';
import { useEffect, useState } from 'react';
function ActivationForm() {
  const [token, setToken] = useState('');
  useEffect(() => { setToken(new URLSearchParams(window.location.search).get('token') || ''); }, []);
  const [password, setPassword] = useState('');
  const [confirm, setConfirm] = useState('');
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');

  async function activate(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault(); setError(''); setSuccess('');
    if (!token) { setError('رابط التفعيل غير مكتمل. اطلب رابطاً جديداً من المدير.'); return; }
    if (password.length < 10) { setError('كلمة المرور يجب ألا تقل عن 10 أحرف.'); return; }
    if (password !== confirm) { setError('تأكيد كلمة المرور غير مطابق.'); return; }
    setBusy(true);
    let data: { error?: string; full_name?: string } | null = null;
    try {
      const response = await fetch('https://vtpdvzhqhfaffyhmqasg.supabase.co/functions/v1/technician-activate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'apikey': 'sb_publishable_N2_oxVpc1z4rUZTcSFZoKw_PKEyNGVz' },
        body: JSON.stringify({ token, password })
      });
      data = await response.json();
      if (!response.ok || data?.error) throw new Error(data?.error || 'تعذر تفعيل الحساب.');
    } catch (activationError) {
      setBusy(false);
      setError(activationError instanceof Error ? activationError.message : 'تعذر تفعيل الحساب.');
      return;
    }
    setBusy(false);
    setSuccess(`تم تفعيل حساب ${data?.full_name || 'الفني'} بنجاح. يمكنك الآن تسجيل الدخول من جهازك.`);
    setPassword(''); setConfirm('');
  }

  return <main className="page"><Header/><section className="activation-page">
    <div className="login activation-card"><div className="symbol">K</div><h2>تفعيل حساب الفني</h2>
      <p>أنشئ كلمة مرور خاصة بك لإكمال تفعيل حسابك في AL KAWADER VII.</p>
      {success ? <div className="success-message">{success}</div> : <form onSubmit={activate}>
        <label>كلمة المرور الجديدة<input type="password" autoComplete="new-password" minLength={10} required value={password} onChange={e=>setPassword(e.target.value)} placeholder="10 أحرف على الأقل"/></label>
        <label>تأكيد كلمة المرور<input type="password" autoComplete="new-password" minLength={10} required value={confirm} onChange={e=>setConfirm(e.target.value)} placeholder="أعد كتابة كلمة المرور"/></label>
        {error && <div className="error" role="alert">{error}</div>}
        <button className="primary" type="submit" disabled={busy}>{busy ? 'جارٍ تفعيل الحساب…' : 'تفعيل الحساب'}</button>
      </form>}
      <small className="notice">رابط التفعيل صالح لمدة 24 ساعة ويُستخدم مرة واحدة.</small>
    </div>
  </section><Footer/></main>;
}

export default function ActivatePage() {
  return <ActivationForm />;
}
function Header(){return <header><div className="mark">K</div><div><b>AL KAWADER <i>VII</i></b><small>مؤسسة الكوادر المتخصصة لأجهزة السلامة</small></div><span className="header-note">نظام إدارة الصيانة والزيارات</span></header>}
function Footer(){return <footer>© مؤسسة الكوادر المتخصصة لأجهزة السلامة <span>AL KAWADER VII</span></footer>}
