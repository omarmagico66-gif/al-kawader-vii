'use client';
import { useEffect, useState } from 'react';
import QRCode from 'qrcode';
import { createClient } from '@supabase/supabase-js';

const supabase = createClient(
  'https://vtpdvzhqhfaffyhmqasg.supabase.co',
  'sb_publishable_N2_oxVpc1z4rUZTcSFZoKw_PKEyNGVz',
  { auth: { persistSession: true, autoRefreshToken: true } }
);
const ADMIN_EMAIL = 'omar.magico66@gmail.com';

type Technician = {
  id: string;
  full_name: string;
  phone: string | null;
  account_status: 'active' | 'suspended';
  created_at?: string;
};
type NewTechnician = { full_name: string; email: string; phone: string };

export default function Home() {
  const [password, setPassword] = useState('');
  const [entered, setEntered] = useState(false);
  const [authLoading, setAuthLoading] = useState(true);
  const [loginLoading, setLoginLoading] = useState(false);
  const [authError, setAuthError] = useState('');
  const [adminName, setAdminName] = useState('');
  const [screen, setScreen] = useState<'home' | 'technicians'>('home');
  const [technicians, setTechnicians] = useState<Technician[]>([]);
  const [loadingTechs, setLoadingTechs] = useState(false);
  const [techError, setTechError] = useState('');
  const [savingTech, setSavingTech] = useState(false);
  const [form, setForm] = useState<NewTechnician>({ full_name: '', email: '', phone: '' });
  const [activationUrl, setActivationUrl] = useState('');
  const [qrData, setQrData] = useState('');
  const [copyMessage, setCopyMessage] = useState('');

  useEffect(() => {
    let live = true;
    supabase.auth.getSession().then(async ({ data }) => {
      if (!live) return;
      if (data.session) {
        const { data: profile } = await supabase.from('user_profiles')
          .select('full_name,role,account_status')
          .eq('id', data.session.user.id).maybeSingle();
        if (live && profile?.role === 'admin' && profile.account_status === 'active') {
          setAdminName(profile.full_name || 'المدير');
          setEntered(true);
        } else if (live) {
          await supabase.auth.signOut();
          setAuthError('الحساب غير مفعّل كمدير.');
        }
      }
      if (live) setAuthLoading(false);
    }).catch(() => {
      if (live) { setAuthError('تعذر الاتصال بخدمة تسجيل الدخول.'); setAuthLoading(false); }
    });
    return () => { live = false; };
  }, []);

  useEffect(() => {
    if (activationUrl) {
      QRCode.toDataURL(activationUrl, { width: 220, margin: 2, errorCorrectionLevel: 'M' })
        .then(setQrData).catch(() => setQrData(''));
    } else setQrData('');
  }, [activationUrl]);

  async function login() {
    setAuthError('');
    if (!password) { setAuthError('اكتب كلمة المرور أولاً.'); return; }
    setLoginLoading(true);
    try {
      const { data, error } = await supabase.auth.signInWithPassword({ email: ADMIN_EMAIL, password });
      if (error) throw error;
      if (!data.user) throw new Error('تعذر التحقق من الحساب.');
      const { data: profile, error: profileError } = await supabase.from('user_profiles')
        .select('full_name,role,account_status').eq('id', data.user.id).single();
      if (profileError || profile?.role !== 'admin' || profile?.account_status !== 'active') {
        await supabase.auth.signOut();
        throw new Error('الحساب لا يملك صلاحية المدير أو أنه موقوف.');
      }
      setAdminName(profile.full_name || 'المدير');
      setEntered(true);
      setPassword('');
    } catch (error) {
      setAuthError(error instanceof Error ? error.message : 'حدث خطأ أثناء تسجيل الدخول.');
    } finally { setLoginLoading(false); }
  }

  async function logout() {
    await supabase.auth.signOut();
    setEntered(false); setScreen('home'); setPassword('');
  }

  async function loadTechnicians() {
    setLoadingTechs(true); setTechError('');
    const { data, error } = await supabase.functions.invoke('technician-admin', { body: { action: 'list' } });
    if (error) setTechError(error.message || 'تعذر تحميل قائمة الفنيين.');
    else if (data?.error) setTechError(data.error);
    else setTechnicians((data?.technicians || []) as Technician[]);
    setLoadingTechs(false);
  }

  async function createTechnician(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault(); setTechError(''); setCopyMessage('');
    if (!form.full_name.trim() || !form.email.trim()) {
      setTechError('اكتب اسم الفني والبريد الإلكتروني.'); return;
    }
    setSavingTech(true);
    const { data, error } = await supabase.functions.invoke('technician-admin', {
      body: { action: 'create', full_name: form.full_name, email: form.email, phone: form.phone }
    });
    setSavingTech(false);
    if (error || data?.error) {
      setTechError(data?.error || error?.message || 'تعذر إنشاء حساب الفني.');
      return;
    }
    const token = data?.activation_token;
    if (!token) { setTechError('تم إنشاء الحساب لكن لم يصل رمز التفعيل. تواصل مع الدعم قبل إعادة المحاولة.'); return; }
    const link = `${window.location.origin}/activate?token=${encodeURIComponent(token)}`;
    setActivationUrl(link);
    setForm({ full_name: '', email: '', phone: '' });
    await loadTechnicians();
  }

  async function changeStatus(tech: Technician) {
    setTechError('');
    const nextStatus = tech.account_status === 'active' ? 'suspended' : 'active';
    const { data, error } = await supabase.functions.invoke('technician-admin', {
      body: { action: 'status', user_id: tech.id, account_status: nextStatus }
    });
    if (error || data?.error) { setTechError(data?.error || error?.message || 'تعذر تحديث حالة الفني.'); return; }
    setTechnicians(current => current.map(item => item.id === tech.id ? { ...item, account_status: nextStatus } : item));
  }

  async function copyActivationLink() {
    try {
      await navigator.clipboard.writeText(activationUrl);
      setCopyMessage('تم نسخ رابط التفعيل.');
    } catch { setCopyMessage('تعذر النسخ تلقائياً. اضغط مطولاً على الرابط لنسخه.'); }
  }

  if (authLoading) return <main className="page"><Header/><section className="hero"><div className="login"><h2>جارٍ التحقق من الجلسة…</h2><p>يرجى الانتظار</p></div></section><Footer/></main>;

  if (!entered) return <main className="page"><Header/><section className="hero">
    <div className="intro"><small className="eyebrow">منصة الكوادر الذكية</small><h1>إدارة الزيارات<br/><em>بسهولة واحترافية</em></h1><p>منصة موحدة لتنظيم أعمال الصيانة الدورية ومتابعة فرق العمل.</p></div>
    <div className="login"><div className="symbol">⌁</div><h2>تسجيل دخول الإدارة</h2><p>أدخل كلمة مرور حساب المدير</p>
      <label>كلمة المرور<input type="password" autoComplete="current-password" value={password} onChange={e=>setPassword(e.target.value)} onKeyDown={e=>{if(e.key==='Enter')login();}} placeholder="أدخل كلمة المرور"/></label>
      {authError && <div className="error" role="alert">{authError}</div>}
      <button className="primary" disabled={loginLoading} onClick={login}>{loginLoading?'جارٍ تسجيل الدخول…':'دخول آمن ←'}</button>
      <small className="notice">الدخول مرتبط بحساب المدير المعتمد.</small>
    </div>
  </section><Footer/></main>;

  return <main className="page"><Header/><section className="dashboard">
    <div className="welcome"><div><small className="eyebrow">لوحة الإدارة</small><h1>{screen === 'technicians' ? 'إدارة الفنيين' : 'أهلاً بك في الكوادر'}</h1><p>{adminName || 'إدارة النظام'}</p></div><button className="logout" onClick={logout}>تسجيل الخروج</button></div>
    <nav className="admin-nav">
      <button className={screen === 'home' ? 'selected' : ''} onClick={() => setScreen('home')}>الرئيسية</button>
      <button className={screen === 'technicians' ? 'selected' : ''} onClick={() => { setScreen('technicians'); void loadTechnicians(); }}>إدارة الفنيين</button>
    </nav>
    {screen === 'home' ? <div className="admin-grid">
      <button className="admin-card" onClick={() => { setScreen('technicians'); void loadTechnicians(); }}>
        <span className="tile-icon">♙</span><strong>إدارة الفنيين</strong><small>إضافة الفنيين ومتابعة حساباتهم وتفعيلها</small><span className="card-link">فتح القسم ←</span>
      </button>
      <div className="panel status-panel"><h2>حالة النظام</h2><p>تم التحقق من حساب المدير والاتصال بخدمة المصادقة.</p><div className="history"><b>حالة المصادقة</b><span className="pill">متصل</span></div><p className="muted">الأقسام الأخرى ستُفعّل بعد مراجعة وربط وظائفها الفعلية.</p></div>
    </div> : <div className="panel">
      <div className="section-head"><div><h2>حسابات الفنيين</h2><p className="muted">إضافة حساب جديد، ومراجعة حالة الحسابات الحالية.</p></div><button className="secondary" onClick={() => void loadTechnicians()} disabled={loadingTechs}>تحديث القائمة</button></div>
      <form className="tech-form" onSubmit={createTechnician}>
        <h3>إضافة فني جديد</h3>
        <div className="form-grid">
          <label>اسم الفني<input required value={form.full_name} onChange={e=>setForm({...form,full_name:e.target.value})} placeholder="الاسم بالكامل"/></label>
          <label>البريد الإلكتروني<input required type="email" value={form.email} onChange={e=>setForm({...form,email:e.target.value})} placeholder="technician@example.com" dir="ltr"/></label>
          <label>رقم الجوال<input value={form.phone} onChange={e=>setForm({...form,phone:e.target.value})} placeholder="05xxxxxxxx" dir="ltr"/></label>
        </div>
        <button className="primary" type="submit" disabled={savingTech}>{savingTech ? 'جارٍ إنشاء الحساب…' : 'إنشاء حساب الفني وإصدار رابط التفعيل'}</button>
      </form>
      {techError && <div className="error" role="alert">{techError}</div>}
      {activationUrl && <div className="activation-box">
        <div><h3>تم إنشاء الحساب</h3><p>أرسل هذا الرابط للفني ليحدد كلمة مروره. الرابط صالح لمدة 24 ساعة ويُستخدم مرة واحدة.</p></div>
        {qrData && <img className="qr" src={qrData} alt="رمز QR لتفعيل حساب الفني"/>}
        <label>رابط التفعيل<input readOnly value={activationUrl} dir="ltr" onFocus={e=>e.currentTarget.select()}/></label>
        <button className="secondary" onClick={copyActivationLink}>نسخ رابط التفعيل</button>
        {copyMessage && <small className="copy-message">{copyMessage}</small>}
      </div>}
      <div className="technician-list">
        <div className="section-head"><h3>الفنيون المسجلون ({technicians.length})</h3>{loadingTechs && <span className="muted">جارٍ التحميل…</span>}</div>
        {!loadingTechs && technicians.length === 0 && <p className="empty">لا توجد حسابات فنيين مسجلة حتى الآن.</p>}
        {technicians.map(tech => <div className="tech-row" key={tech.id}>
          <div><strong>{tech.full_name || 'فني بدون اسم'}</strong><small>{tech.phone || 'لا يوجد رقم جوال مسجل'}</small></div>
          <span className={tech.account_status === 'active' ? 'state active' : 'state suspended'}>{tech.account_status === 'active' ? 'مفعّل' : 'موقوف / بانتظار التفعيل'}</span>
          {tech.account_status === 'active' ? <button className="secondary" onClick={() => void changeStatus(tech)}>إيقاف</button> : <span className="pending-note">موقوف / بانتظار التفعيل</span>}
        </div>)}
      </div>
    </div>}
  </section><Footer/></main>;
}

function Header(){return <header><div className="mark">K</div><div><b>AL KAWADER <i>VII</i></b><small>مؤسسة الكوادر المتخصصة لأجهزة السلامة</small></div><span className="header-note">نظام إدارة الصيانة والزيارات</span></header>}
function Footer(){return <footer>© مؤسسة الكوادر المتخصصة لأجهزة السلامة <span>AL KAWADER VII</span></footer>}
