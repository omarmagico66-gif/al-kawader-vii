# سجل التغييرات
## V2 — 2026-11-26
- إضافة شاشة تسجيل زيارة دورية.
- إضافة أنظمة السلامة الاثني عشر وحالات الفحص.
- إضافة وصف العطل والتحقق منه.
- إضافة قسم طفايات الحريق والتعبئة.
- إضافة طلب إذن GPS والتحقق من الإحداثيات.
- إضافة سجل أكواد زيارات تجريبي.
## V1
- الواجهة الأساسية وتسجيل الدخول التجريبي ولوحات أولية.

## V2.1 — مصادقة المدير
- استبدال الدخول التجريبي بتسجيل دخول Supabase Auth والتحقق من صلاحية المدير.


## V2.2 — Cloudflare deployment preparation
- Added OpenNext Cloudflare adapter configuration.
- Added Wrangler Workers configuration and deployment scripts.
- Added Arabic deployment instructions.
- No database schema or Supabase records changed.
- Not deployed; dependency installation/build still require verification in an environment with npm network access.

## V2.5.0 — إدارة الفنيين

- إضافة شاشة إدارة الفنيين إلى لوحة المدير.
- ربط عرض الفنيين وإنشاء الحسابات وتغيير حالة الحساب بدالة Supabase `technician-admin` الموجودة.
- إضافة صفحة `/activate` لتعيين كلمة مرور الفني باستخدام رابط التفعيل.
- إنشاء رمز QR لرابط التفعيل داخل المتصفح.
- لا توجد تغييرات على مخطط قاعدة البيانات أو سجلاتها.
- لم يتم نشر واجهة Cloudflare من هذه الحزمة.
