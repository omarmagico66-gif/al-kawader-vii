import { createClient } from "npm:@supabase/supabase-js@2.57.0";

const cors = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, apikey, content-type, x-client-info",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
};
const json = (body: unknown, status = 200) =>
  new Response(JSON.stringify(body), { status, headers: { ...cors, "Content-Type": "application/json" } });
const randomToken = () => {
  const bytes = crypto.getRandomValues(new Uint8Array(32));
  return btoa(String.fromCharCode(...bytes)).replaceAll("+", "-").replaceAll("/", "_").replaceAll("=", "");
};
const sha256 = async (value: string) => {
  const digest = await crypto.subtle.digest("SHA-256", new TextEncoder().encode(value));
  return Array.from(new Uint8Array(digest), byte => byte.toString(16).padStart(2, "0")).join("");
};

Deno.serve(async req => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: cors });
  if (req.method !== "POST") return json({ error: "Method not allowed" }, 405);
  const url = Deno.env.get("SUPABASE_URL"), anon = Deno.env.get("SUPABASE_ANON_KEY"), service = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY");
  if (!url || !anon || !service) return json({ error: "Server configuration is incomplete" }, 500);
  const match = (req.headers.get("Authorization") || "").match(/^Bearer\s+(.+)$/i);
  const jwt = match?.[1]?.trim() || "";
  if (!jwt) return json({ error: "Unauthorized" }, 401);
  const caller = createClient(url, anon, { auth: { persistSession: false, autoRefreshToken: false } });
  const admin = createClient(url, service, { auth: { persistSession: false, autoRefreshToken: false } });
  const { data: authData, error: authError } = await caller.auth.getUser(jwt);
  if (authError || !authData.user) return json({ error: "Invalid session" }, 401);
  const { data: profile } = await admin.from("user_profiles").select("role,account_status").eq("id", authData.user.id).maybeSingle();
  if (profile?.role !== "admin" || profile.account_status !== "active") return json({ error: "Admin access required" }, 403);

  try {
    const body = await req.json();
    if (body.action === "list") {
      const { data, error } = await admin.from("user_profiles")
        .select("id,full_name,phone,account_status,created_at")
        .eq("role", "technician").order("created_at", { ascending: false });
      if (error) throw error;
      const { data: authUsers, error: usersError } = await admin.auth.admin.listUsers({ page: 1, perPage: 1000 });
      if (usersError) throw usersError;
      const authById = new Map((authUsers.users || []).map(user => [user.id, user]));
      const technicians = (data || []).map(tech => ({
        ...tech,
        email: authById.get(tech.id)?.email || "",
        last_sign_in_at: authById.get(tech.id)?.last_sign_in_at || null
      }));
      return json({ technicians });
    }
    if (body.action === "status") {
      const id = String(body.user_id || ""), status = body.account_status;
      if (!id || !["active", "suspended"].includes(status)) return json({ error: "Invalid request" }, 400);
      const { data, error } = await admin.from("user_profiles").update({ account_status: status })
        .eq("id", id).eq("role", "technician").select("id,account_status").maybeSingle();
      if (error) throw error;
      if (!data) return json({ error: "Technician not found" }, 404);
      return json({ technician: data });
    }
    if (body.action === "create") {
      const email = String(body.email || "").trim().toLowerCase();
      const full_name = String(body.full_name || "").trim();
      const phone = String(body.phone || "").trim() || null;
      if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email) || full_name.length < 2) return json({ error: "أدخل اسم الفني وبريده الإلكتروني الصحيح." }, 400);
      const temporaryPassword = randomToken() + "Aa1!";
      const { data: created, error: createError } = await admin.auth.admin.createUser({ email, password: temporaryPassword, email_confirm: true });
      if (createError || !created.user) return json({ error: createError?.message || "تعذر إنشاء الحساب" }, 400);
      const { error: profileError } = await admin.from("user_profiles").insert({
        id: created.user.id, full_name, phone, role: "technician", account_status: "suspended", created_by: authData.user.id
      });
      if (profileError) { await admin.auth.admin.deleteUser(created.user.id); throw profileError; }
      const token = randomToken();
      const { error: tokenError } = await admin.rpc("issue_technician_activation_token", {
        p_user_id: created.user.id, p_token_hash: await sha256(token), p_created_by: authData.user.id,
        p_expires_at: new Date(Date.now() + 86400000).toISOString()
      });
      if (tokenError) {
        await admin.from("user_profiles").delete().eq("id", created.user.id);
        await admin.auth.admin.deleteUser(created.user.id);
        throw tokenError;
      }
      return json({ technician: { id: created.user.id, full_name, email, phone, account_status: "suspended" }, activation_token: token, expires_in_hours: 24 });
    }
    return json({ error: "Unknown action" }, 400);
  } catch (error) {
    return json({ error: error instanceof Error ? error.message : "Unexpected error" }, 500);
  }
});
