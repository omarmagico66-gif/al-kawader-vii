import { createClient } from "npm:@supabase/supabase-js@2.57.0";
const cors = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, apikey, content-type, x-client-info",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
};
const json = (body: unknown, status = 200) => new Response(JSON.stringify(body), { status, headers: { ...cors, "Content-Type": "application/json" } });
const sha256 = async (value: string) => {
  const digest = await crypto.subtle.digest("SHA-256", new TextEncoder().encode(value));
  return Array.from(new Uint8Array(digest), byte => byte.toString(16).padStart(2, "0")).join("");
};
Deno.serve(async req => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: cors });
  if (req.method !== "POST") return json({ error: "Method not allowed" }, 405);
  const url = Deno.env.get("SUPABASE_URL"), key = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY");
  if (!url || !key) return json({ error: "Server configuration is incomplete" }, 500);
  try {
    const { token, password } = await req.json();
    if (typeof token !== "string" || token.length < 30 || typeof password !== "string" || password.length < 10)
      return json({ error: "رمز التفعيل أو كلمة المرور غير صالح. كلمة المرور يجب ألا تقل عن 10 أحرف." }, 400);
    const admin = createClient(url, key, { auth: { persistSession: false, autoRefreshToken: false } });
    const { data: claimed, error: claimError } = await admin.rpc("claim_technician_activation_token", { p_token_hash: await sha256(token) });
    const row = claimed?.[0];
    if (claimError || !row) return json({ error: "رابط التفعيل غير صالح أو منتهي أو تم استخدامه من قبل." }, 400);
    const { error: passError } = await admin.auth.admin.updateUserById(row.auth_user_id, { password });
    if (passError) return json({ error: "تعذر تعيين كلمة المرور. اطلب من المدير إصدار رمز جديد." }, 400);
    const { data: profile, error: profileError } = await admin.from("user_profiles").update({ account_status: "active" })
      .eq("id", row.auth_user_id).eq("role", "technician").select("id,full_name").maybeSingle();
    if (profileError || !profile) return json({ error: "تم تعيين كلمة المرور لكن تعذر تفعيل الملف. تواصل مع المدير." }, 500);
    const { data: userData } = await admin.auth.admin.getUserById(row.auth_user_id);
    return json({ ok: true, email: userData.user?.email || "", full_name: profile.full_name });
  } catch {
    return json({ error: "تعذر إكمال التفعيل." }, 500);
  }
});
